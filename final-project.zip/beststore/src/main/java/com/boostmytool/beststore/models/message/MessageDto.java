package com.boostmytool.beststore.models.message;

import java.time.LocalDateTime;

public class MessageDto {
    private String text;

    private LocalDateTime time;

    private Integer userId;

    private Integer receiverId;

    private Integer channelId;

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public LocalDateTime getTime() { return time; }
    public void setTime(LocalDateTime time) { this.time = time; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public Integer getReceiverId() { return receiverId; }
    public void setReceiverId(Integer receiverId) { this.receiverId = receiverId; }

    public Integer getChannelId() { return channelId; }
    public void setChannelId(Integer channelId) { this.channelId = channelId; }
}
