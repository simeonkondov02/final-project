package com.boostmytool.beststore.controllers.channels.editChannel;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.channel.ChannelDto;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/channels")
public class EditChannelController {
    @Autowired private ChannelsRepository channelsRepository;
    @Autowired private UsersRepository usersRepository;

    @PostMapping("/edit")
    public String editChannel(Model model, @RequestParam int id, @Valid @ModelAttribute ChannelDto channelDto, BindingResult result) {
       try {
           Channel channel = channelsRepository.findById(id).get();
           model.addAttribute("channel", channel);

           if (result.hasErrors()) { return "channels/EditChannel"; }

           channel.setName(channelDto.getName());

           Set<Integer> adminIds = channelDto.getAdminIds();
           Set<Integer> memberIds = channelDto.getMembersIds();

           Set<User> admins = new HashSet<>();
           Set<User> members = new HashSet<>();

           if (adminIds != null) {
               for (Integer adminId : adminIds) {
                   User admin = usersRepository.findById(adminId).orElseThrow(() -> new Exception("User with ID " + adminId + " not found"));
                   admins.add(admin);
               }
           }

           if (memberIds != null) {
               for (Integer memberId: memberIds) {
                   User member = usersRepository.findById(memberId).orElseThrow(() -> new Exception("User with ID " + memberId + " not found"));
                   members.add(member);
               }
           }

           channel.setAdmins(admins);
           channel.setMembers(members);

           channelsRepository.save(channel);
       } catch (Exception ex) {
           System.out.println("Exception: " + ex.getMessage());
           return "redirect:/";
       }
    return "redirect:/";
    }
}
