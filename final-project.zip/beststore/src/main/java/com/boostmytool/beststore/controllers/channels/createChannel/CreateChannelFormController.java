package com.boostmytool.beststore.controllers.channels.createChannel;

import com.boostmytool.beststore.models.channel.ChannelDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/channels")
public class CreateChannelFormController {

    @GetMapping("/create")
    public String showCreatePage(Model model) {
        ChannelDto channelDto = new ChannelDto();
        model.addAttribute("channelDto", channelDto);
        return "channels/CreateChannel";
    }
}
