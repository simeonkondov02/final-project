package com.boostmytool.beststore.controllers.users.editUser;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashSet;
import java.util.Set;

@Controller
@RequestMapping("/users")
public class AddUserToChannelsController {
    @Autowired private ChannelsRepository channelsRepository;
    @Autowired private UsersRepository usersRepository;

    @PostMapping("/add-users-to-channel")
    @Transactional
    public String addUserToChannel(@RequestParam int id, @Valid @ModelAttribute UserDto userDto, BindingResult result, Model model) {
        try {
            User user = usersRepository.findById(id).orElseThrow(() -> new Exception("User not found"));

            Set<Integer> channelIds = userDto.getChannelsIds();
            Set<Channel> selectedChannels = new HashSet<>();

            if (channelIds != null && !channelIds.isEmpty()) {
                for (Integer channelId : channelIds) {
                    Channel channel = channelsRepository.findById(channelId)
                            .orElseThrow(() -> new Exception("Channel with ID " + channelId + " not found"));
                    selectedChannels.add(channel);
                }
            }

            user.setChannels(selectedChannels);

            usersRepository.save(user);
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "users/AddUserToChannel";
        }

        return "redirect:/users";
    }

}
