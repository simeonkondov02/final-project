package com.boostmytool.beststore.controllers.channels.editChannel;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.channel.ChannelDto;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;

@Controller
@RequestMapping("/channels")
public class EditChannelFormController {

    @Autowired
    ChannelsRepository channelsRepository;
    @Autowired
    UsersRepository usersRepository;

    @GetMapping("/edit")
    public String showEditPage(@RequestParam int id, Model model) {
        try {
            System.out.println("Requested Channel ID: " + id);

            // Проверяваме дали каналът съществува
            Channel channel = channelsRepository.findById(id).orElseThrow(() -> new Exception("Channel not found"));
            System.out.println("Channel found: " + channel.getName());

            ChannelDto channelDto = new ChannelDto();
            channelDto.setName(channel.getName());

            // Поставяме стойности за администратори и участници
            Set<Integer> adminIds = channel.getAdmins().stream().map(a -> a.getId()).collect(Collectors.toSet());
            channelDto.setAdminIds(adminIds);

            Set<Integer> memberIds = channel.getMembers().stream().map(m -> m.getId()).collect(Collectors.toSet());
            channelDto.setMembersIds(memberIds);

            // Вземаме всички потребители
            var allUsers = usersRepository.findAll();
            System.out.println("Total users: " + allUsers.size());

            // Извличаме само участниците
            var members = allUsers.stream().filter(user -> memberIds.contains(user.getId())).collect(Collectors.toList());
            System.out.println("Total members in channel: " + members.size());

            // Логваме атрибутите, които ще подаваме към шаблона
            System.out.println("channelDto: " + channelDto);
            System.out.println("allUsers: " + allUsers);
            System.out.println("members: " + members);

            // Добавяме данните в модела
            model.addAttribute("channelDto", channelDto);
            model.addAttribute("users", allUsers);
            model.addAttribute("members", members);

        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            ex.printStackTrace();  // Печатаме пълния стек на грешката
            return "redirect:/";  // Може да го промените на конкретна страница за грешка
        }

        return "channels/EditChannel";
    }
}
