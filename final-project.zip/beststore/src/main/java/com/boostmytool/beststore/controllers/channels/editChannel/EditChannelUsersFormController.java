package com.boostmytool.beststore.controllers.channels.editChannel;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.channel.ChannelDto;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;

@Controller
@RequestMapping("/channels")
public class EditChannelUsersFormController {
    @Autowired
    ChannelsRepository channelsRepository;
    @Autowired
    UsersRepository usersRepository;

    @GetMapping("/users")
    public String showEditPage(@RequestParam int id, Model model) {
        try {
            Channel channel = channelsRepository.findById(id).orElseThrow(() -> new Exception("Channel not found"));

            ChannelDto channelDto = new ChannelDto();

            channelDto.setName(channel.getName());

            Set<Integer> adminIds = channel.getAdmins().stream().map(a -> a.getId()).collect(Collectors.toSet());
            channelDto.setAdminIds(adminIds);

            Set<Integer> memberIds = channel.getMembers().stream().map(m -> m.getId()).collect(Collectors.toSet());
            channelDto.setMembersIds(memberIds);

            var allUsers = usersRepository.findAll();

            var members = allUsers.stream().filter(user -> memberIds.contains(user.getId())).collect(Collectors.toList());

            model.addAttribute("channelDto", channelDto);
            model.addAttribute("users", allUsers);
            model.addAttribute("members", members);

        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "redirect:/channels";
        }

        return "channels/EditChannelUsers";
    }
}
