package com.boostmytool.beststore.controllers.users.deleteUser;

import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
@RequestMapping("/users")
public class DeleteUserController {
    @Autowired private UsersRepository usersRepository;

    @GetMapping("/delete")
    public String deleteUser(@RequestParam int id) {
        try {
            User user = usersRepository.findById(id).get();

            Path imagePath = Paths.get("public/images/" + user.getImageFileName());

            try { Files.delete(imagePath); }
            catch (Exception ex) { System.out.println("Exception: " + ex.getMessage()); }

            usersRepository.delete(user);
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
        }

        return "redirect:/";
    }
}
