package com.boostmytool.beststore.controllers.channels.showChannels;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.services.ChannelsRepository;

@Controller
@RequestMapping("/channels")
public class ShowChannelsController {
    @Autowired private ChannelsRepository channelsRepository;

    @GetMapping({"", "/"})
    public String showChannels(Model model) {
        List<Channel> channels = channelsRepository.findAll();
        model.addAttribute("channels", channels);
        return "channels/index";
    }
}
