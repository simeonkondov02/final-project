package com.boostmytool.beststore.controllers.users.showUsers;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.UsersRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/users")
public class ShowUsersController {
    @Autowired private UsersRepository usersRepository;

    @GetMapping("/list")
    public String showUserList2(Model model, HttpSession session) {
        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");
        List<User> users;

        if (loggedUserId != null) {
            users = usersRepository.findAll().stream().filter(u -> u.getId() != loggedUserId).collect(Collectors.toList());

            User loggedUser = usersRepository.findById(loggedUserId).orElse(null);
            Set<User> friends = loggedUser.getFriends();

            model.addAttribute("loggedUser", loggedUser);
            model.addAttribute("friends", friends);
        } else { users = usersRepository.findAll(); }

        model.addAttribute("users", users);
        return "users/index";
    }
}
