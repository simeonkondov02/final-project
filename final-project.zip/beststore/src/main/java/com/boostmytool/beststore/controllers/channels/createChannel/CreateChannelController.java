package com.boostmytool.beststore.controllers.channels.createChannel;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.channel.ChannelDto;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import scala.collection.immutable.List;

@Controller
@RequestMapping("/channels")
public class CreateChannelController {
    @Autowired ChannelsRepository channelsRepository;
    @Autowired private UsersRepository usersRepository;

    @PostMapping("/create")
    public String CreateChannel(@Valid @ModelAttribute ChannelDto channelDto, BindingResult result, HttpSession session) {
        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");

        if (loggedUserId == null) {
            return "redirect:/users/login"; // Redirect if no logged user
        }

        Optional<User> ownerOptional = usersRepository.findById(loggedUserId);
        if (ownerOptional.isEmpty()) {
            result.rejectValue("name", "error.channelDto", "User not found");
            return "channels/CreateChannel"; // Return to form if error
        }

        User owner = ownerOptional.get();

        // Create a new channel
        Channel channel = new Channel(channelDto.getName(), owner);

        // Add owner to members list
        Set<User> members = new HashSet<>();
        members.add(owner);
        channel.setMembers(members);

        // Save the channel (which will automatically insert the foreign key into channel_members)
        channelsRepository.save(channel);

        return "redirect:/"; // Redirect to home or desired page after creation
    }


}
