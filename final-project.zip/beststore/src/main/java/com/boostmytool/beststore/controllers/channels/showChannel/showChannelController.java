package com.boostmytool.beststore.controllers.channels.showChannel;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.ChannelsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.Set;

@Controller
@RequestMapping("/channels")
public class showChannelController {
    @Autowired
    ChannelsRepository channelsRepository;

    @GetMapping("/channel")
    public String showChannelPage(Model model, @RequestParam int id) {
        try {
            Channel channel = channelsRepository.findById(id).orElseThrow(() ->
                    new IllegalArgumentException("Channel not found with id: " + id)
            );

            Set<User> members = channel.getMembers();

            model.addAttribute("channel", channel);
            model.addAttribute("members", members);

            return "channels/ShowChannel"; // Правилно име на шаблона
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "redirect:/channels"; // Пренасочване при грешка
        }
    }
}
