package com.boostmytool.beststore.controllers.messages.createMessage;

import org.springframework.stereotype.Controller;

@Controller
//@RequestMapping("/messages")
public class CreateMessageFromController {

//    @GetMapping("/create")
//    public String showCreateMessagePage(Model model, HttpSession session) {
//        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");
//        Integer receiverId = (Integer) session.getAttribute("receiverId");
//        Integer channelId = (Integer) session.getAttribute("channelId");
//
//        MessageDto messageDto = new MessageDto();
//        messageDto.setUserId(loggedUserId);
//        messageDto.setReceiverId(receiverId);
//        messageDto.setChannelId(channelId);
//
//        model.addAttribute("messageDto", messageDto);
//
//        return "index";
//    }
}
