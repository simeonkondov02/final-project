package com.boostmytool.beststore.models.user;

import com.boostmytool.beststore.models.channel.Channel;
import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String name;

	private String imageFileName;

	@ManyToMany
	@JoinTable(
		name = "user_friends",
		joinColumns = @JoinColumn(name = "user_id"),
		inverseJoinColumns = @JoinColumn(name = "friend_id")
	)
	private Set<User> friends = new HashSet<>();

	@ManyToMany
	@JoinTable(
			name = "channel_members",
			joinColumns = @JoinColumn(name = "user_id"),
			inverseJoinColumns = @JoinColumn(name = "channel_id")
	)
	private Set<Channel> channels = new HashSet<>();

	public User () {
		this.name = "";
		this.imageFileName = "";
	}

	public User (String name, String imageFileName) {
		this.name = name;
		this.imageFileName = imageFileName;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getImageFileName() {
		return imageFileName;
	}
	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}

	public Set<User> getFriends() { return friends; }
	public void setFriends(Set<User> friends) { this.friends = friends; }

	public Set<Channel> getChannels() { return channels; }
	public void setChannels(Set<Channel> channels) { this.channels = channels; }
}
