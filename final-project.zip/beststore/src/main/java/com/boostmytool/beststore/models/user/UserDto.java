package com.boostmytool.beststore.models.user;

import jakarta.validation.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

import java.util.Set;

public class UserDto {
	@NotEmpty(message = "Enter your name!")
	private String name;

	private MultipartFile imageFile;

	private Set<Integer> friendsIds;

	private Set<Integer> channelsIds;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public MultipartFile getImageFile() {
		return imageFile;
	}
	public void setImageFile(MultipartFile imageFile) {
		this.imageFile = imageFile;
	}

	public Set<Integer> getFriendsIds() { return friendsIds; }
	public void setFriendsIds(Set<Integer> friendsIds) { this.friendsIds = friendsIds; }

	public Set<Integer> getChannelsIds() { return channelsIds; }
	public void setChannelsIds(Set<Integer> channelsIds) { this.channelsIds = channelsIds; }
}
