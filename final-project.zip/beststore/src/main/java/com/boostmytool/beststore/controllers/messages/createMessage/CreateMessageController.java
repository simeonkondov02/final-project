package com.boostmytool.beststore.controllers.messages.createMessage;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.message.Message;
import com.boostmytool.beststore.models.message.MessageDto;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.MessagesRepository;
import com.boostmytool.beststore.services.UsersRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping({"/", ""})
public class CreateMessageController {

    @Autowired
    private MessagesRepository messagesRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private ChannelsRepository channelsRepository;

    @PostMapping("/messages/create")
    public String createMessage(@Valid @ModelAttribute MessageDto messageDto, BindingResult result, HttpSession session) {
        // Проверка за валидност на данните
        if (result.hasErrors() || (messageDto.getUserId() != null && messageDto.getUserId().equals(messageDto.getReceiverId()))) {
            return "index"; // Връщане при грешка
        }

        // Вземаме стойностите от сесията
        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");
        Integer receiverId = (Integer) session.getAttribute("receiverId");
        Integer channelId = (Integer) session.getAttribute("channelId");
        // Задаваме стойностите на messageDto директно от сесията
        if (messageDto.getUserId() == null && loggedUserId != null) {
            messageDto.setUserId(loggedUserId); // Използваме loggedUserId като изпращач
        }
        if (messageDto.getReceiverId() == null && receiverId != null) {
            messageDto.setReceiverId(receiverId); // Използваме receiverId от сесията
        }
        if (messageDto.getChannelId() == null && channelId != null) {
            messageDto.setChannelId(channelId); // Използваме channelId от сесията
        }

        // Създаваме съобщението
        Message message = new Message();
        message.setText(messageDto.getText());
        message.setTime(LocalDateTime.now());

        // Намиране на подателя
        Optional<User> senderOptional = usersRepository.findById(messageDto.getUserId());
        if (senderOptional.isEmpty()) {
            result.rejectValue("userId", "error.messageDto", "Sender not found");
            return "index";
        }
        message.setSender(senderOptional.get());

        // Намиране на получателя или канала
        if (messageDto.getReceiverId() != null) {
            Optional<User> receiverOptional = usersRepository.findById(messageDto.getReceiverId());
            if (receiverOptional.isEmpty()) {
                result.rejectValue("receiverId", "error.messageDto", "Receiver not found");
                return "index";
            }
            message.setReceiver(receiverOptional.get());
        } else if (messageDto.getChannelId() != null) {
            Optional<Channel> channelOptional = channelsRepository.findById(messageDto.getChannelId());
            if (channelOptional.isEmpty()) {
                result.rejectValue("channelId", "error.messageDto", "Channel not found");
                return "index";
            }
            message.setChannel(channelOptional.get());
        } else {
            result.reject("error.messageDto", "Either receiver or channel must be provided");
            return "index";
        }

        // Записваме съобщението
        messagesRepository.save(message);
        return "redirect:/"; // Пренасочване след успешно създаване
    }

}
