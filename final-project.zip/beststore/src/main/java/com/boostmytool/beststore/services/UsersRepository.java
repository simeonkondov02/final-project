package com.boostmytool.beststore.services;

import com.boostmytool.beststore.models.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepository extends JpaRepository<User, Integer> {

}
