package com.boostmytool.beststore.controllers.users.logIn;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.UsersRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/users")
public class LogInFromController {
    @Autowired UsersRepository usersRepository;

    @GetMapping("/login")
    public String showLogInPage(Model model) {
        model.addAttribute("id", new UserDto());
        return "users/LogIn";
    }

    @PostMapping("/login")
    public String processLogIn(Integer id, Model model, HttpSession session) {
        Optional<User> user = usersRepository.findById(id);

        if (user.isPresent()){
            session.setAttribute("loggedUserId", id);
            System.out.println("logged: " + id);
            return "redirect:/";
        } else {
            model.addAttribute("error", "Invalid ID");
            return "users/LogIn";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // Премахваме логнатия потребител от сесията
        session.removeAttribute("loggedUserId");
        return "redirect:/";
    }
}
