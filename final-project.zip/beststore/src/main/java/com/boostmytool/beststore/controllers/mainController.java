package com.boostmytool.beststore.controllers;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.message.Message;
import com.boostmytool.beststore.models.message.MessageDto;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.MessagesRepository;
import com.boostmytool.beststore.services.UsersRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class mainController {

    @Autowired private UsersRepository usersRepository;
    @Autowired private ChannelsRepository channelsRepository;
    @Autowired private MessagesRepository messagesRepository;

    @GetMapping({"", "/"})
    public String loggedUserController(HttpSession session, Model model) {
        List<User> users = usersRepository.findAll();
        List<Channel> channels = channelsRepository.findAll();

        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");
        Integer receiverId = (Integer) session.getAttribute("receiverId");
        Integer channelId = (Integer) session.getAttribute("channelId");

        model.addAttribute("users", users);
        model.addAttribute("channels", channels);

        if (receiverId != null) { model.addAttribute("receiverId", receiverId); }
        if (channelId != null) { model.addAttribute("channelId", channelId); }

        Channel channel = (channelId != null) ? channelsRepository.findById(channelId).orElse(null) : null;
        User receiver = (receiverId != null) ? usersRepository.findById(receiverId).orElse(null) : null;


        if (loggedUserId != null) {
            model.addAttribute("loggedUserId", loggedUserId);

            Optional<User> user = usersRepository.findById(loggedUserId);

            if (user.isPresent()) {
                User loggedUser = user.get();
                model.addAttribute("user", loggedUser);

                if (channelId != null) {
                    List<Message> channelMessages = messagesRepository.findAll().stream()
                            .filter(message -> message.getChannel() != null && message.getChannel().getId() == channelId)
                            .collect(Collectors.toList());

                    if (channel != null) {
                        if (loggedUser.equals(channel.getOwner())) {
                            model.addAttribute("userRights", "owner");
                        } else if (channel.getAdmins().contains(loggedUser)) {
                            model.addAttribute("userRights", "admin");
                        } else { model.addAttribute("userRights", "participant"); }
                    }

                    model.addAttribute("messages", channelMessages);
                    model.addAttribute("channel", channel);

                } else if (receiverId != null) {
                    List<Message> privateMessages = messagesRepository.findAll().stream()
                            .filter(message -> message.getChannel() == null && message.getReceiver() != null &&
                                    ((message.getSender().getId() == loggedUserId && message.getReceiver().getId() == receiverId) ||
                                            (message.getSender().getId() == receiverId && message.getReceiver().getId() == loggedUserId)))
                            .collect(Collectors.toList());

                    model.addAttribute("messages", privateMessages);
                    model.addAttribute("receiver", receiver);

                } else { model.addAttribute("messages", null); }
            }
        }

        MessageDto messageDto = new MessageDto();
        model.addAttribute("messageDto", messageDto);

        return "index";
    }

    @GetMapping("/messages/receiver")
    public String selectReceiver(@RequestParam("id") Integer id, HttpSession session, Model model) {
        session.setAttribute("receiverId", id);
        model.addAttribute("receiverId", id);
        session.setAttribute("channelId", null);
        return "redirect:/";
    }

    @GetMapping("/messages/channel")
    public String selectChannel(@RequestParam("id") Integer id, HttpSession session, Model model) {
        session.setAttribute("channelId", id);
        model.addAttribute("channelId", id);
        session.setAttribute("receiverId", null);
        return "redirect:/";
    }

    @GetMapping("/messages/create")
    public String showCreateMessagePage(Model model, HttpSession session) {
        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");
        Integer receiverId = (Integer) session.getAttribute("receiverId");
        Integer channelId = (Integer) session.getAttribute("channelId");

        if (loggedUserId != null) {
            MessageDto messageDto = new MessageDto();
            messageDto.setUserId(loggedUserId);
            messageDto.setReceiverId(receiverId);
            messageDto.setChannelId(channelId);
            model.addAttribute("messageDto", messageDto);
        } else {
            model.addAttribute("messageDto", new MessageDto());
        }

        return "redirect:/";
    }
}