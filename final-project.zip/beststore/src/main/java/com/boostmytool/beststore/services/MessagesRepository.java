package com.boostmytool.beststore.services;

import com.boostmytool.beststore.models.message.Message;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessagesRepository extends JpaRepository<Message, Integer> {
}
