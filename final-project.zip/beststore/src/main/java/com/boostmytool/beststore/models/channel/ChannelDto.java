package com.boostmytool.beststore.models.channel;

import java.util.Set;

import jakarta.validation.constraints.NotEmpty;

public class ChannelDto {
    @NotEmpty(message = "Select channel")
    private String name;

    private Set<Integer> adminIds;

    private Set<Integer> membersIds;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Set<Integer> getAdminIds() { return adminIds; }
    public void setAdminIds(Set<Integer> adminIds) { this.adminIds = adminIds; }

    public Set<Integer> getMembersIds() { return membersIds; }
    public void setMembersIds(Set<Integer> membersIds) { this.membersIds = membersIds; }
}
