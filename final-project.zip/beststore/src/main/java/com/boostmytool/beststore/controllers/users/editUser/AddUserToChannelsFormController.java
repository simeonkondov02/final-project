package com.boostmytool.beststore.controllers.users.editUser;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;

@Controller
@RequestMapping("/users")
public class AddUserToChannelsFormController {
    @Autowired UsersRepository usersRepository;
    @Autowired ChannelsRepository channelsRepository;

    @GetMapping("/add-users-to-channel")
    public String showAddUserToChannelPage(Model model, @RequestParam int id) {
        try {
            User user = usersRepository.findById(id).get();
            model.addAttribute("user", user);

            UserDto userDto = new UserDto();
            userDto.setName(user.getName());

            Set<Integer> channelIds = user.getChannels().stream().map(c -> c.getId()).collect(Collectors.toSet());
            userDto.setChannelsIds(channelIds);

            var channels = channelsRepository.findAll();

            model.addAttribute("userDto", userDto);
            model.addAttribute("channels", channels);
        } catch(Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "redirect:/users";
        }

        return "users/AddUserToChannel";
    }
}
