package com.boostmytool.beststore.controllers.users.createUser;

import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.UsersRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;

@Controller
@RequestMapping("/users")
public class CreateUserController {
    @Autowired private UsersRepository usersRepository;

    @PostMapping("/create")
    public String createUser(@Valid @ModelAttribute UserDto userDto, BindingResult result) {

        if (userDto.getImageFile().isEmpty()) {
            result.addError(new FieldError("userDto", "imageFile", "The image file is required"));
        }

        if (result.hasErrors()) { return "users/CreateUser"; }

        MultipartFile image = userDto.getImageFile();
        Date createdAt = new Date();
        String storageFileName = createdAt.getTime() + "_" + image.getOriginalFilename();

        try {
            String uploadDir = "public/images/";
            Path uploadPath = Paths.get(uploadDir);

            if (!Files.exists(uploadPath)) { Files.createDirectories(uploadPath); }

            try (InputStream inputStream = image.getInputStream()) {
                Files.copy(inputStream, Paths.get(uploadDir + storageFileName), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) { System.out.println("Exception: " + ex.getMessage()); }

        User user = new User(userDto.getName(), storageFileName);

        usersRepository.save(user);

        return "redirect:/";
    }
}
