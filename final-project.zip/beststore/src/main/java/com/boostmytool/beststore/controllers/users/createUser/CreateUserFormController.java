package com.boostmytool.beststore.controllers.users.createUser;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/users")
public class CreateUserFormController {
    @Autowired UsersRepository usersRepository;
    @Autowired ChannelsRepository channelsRepository;

    @GetMapping("/create")
    public String showCreatePage(Model model) {
        UserDto userDto = new UserDto();
        List<User> users = usersRepository.findAll();
        List<Channel> channels = channelsRepository.findAll();

        model.addAttribute("userDto", userDto);
        model.addAttribute("users", users);
        model.addAttribute("channels", channels);
        return "users/CreateUser";
    }


}
