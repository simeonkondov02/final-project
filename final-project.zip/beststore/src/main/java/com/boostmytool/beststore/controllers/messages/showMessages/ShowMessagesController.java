package com.boostmytool.beststore.controllers.messages.showMessages;

import com.boostmytool.beststore.models.message.Message;
import com.boostmytool.beststore.services.MessagesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/messages")
public class ShowMessagesController {
    @Autowired MessagesRepository messagesRepository;

    @RequestMapping({"", "/"})
    public String showMessages(Model model) {
        List<Message> messages = messagesRepository.findAll();
        model.addAttribute("messages", messages);
        return "messages/index";
    }
}
