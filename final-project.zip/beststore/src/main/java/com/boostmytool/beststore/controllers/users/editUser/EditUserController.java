package com.boostmytool.beststore.controllers.users.editUser;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ExpressionException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.ChannelsRepository;
import com.boostmytool.beststore.services.UsersRepository;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/users")
public class EditUserController {
    @Autowired private UsersRepository usersRepository;
    @Autowired private ChannelsRepository channelsRepository;

    @PostMapping("/edit")
    public String editUser(Model model, @RequestParam int id, @Valid @ModelAttribute UserDto userDto, BindingResult result) {
        try {
            User user = usersRepository.findById(id).orElseThrow(() -> new Exception("User not found"));
            model.addAttribute("user", user);
            model.addAttribute("channels", channelsRepository.findAll());

            if (result.hasErrors()) { return "users/EditUser"; }

            user.setName(userDto.getName());

            Set<Integer> channelIds = userDto.getChannelsIds();
            Set<Channel> selectedChannels = new HashSet<>();

            if (channelIds != null && !channelIds.isEmpty()) {
                for (Integer channelId : channelIds) {
                    Channel channel = channelsRepository.findById(channelId)
                            .orElseThrow(() -> new Exception("Channel with ID " + channelId + " not found"));
                    selectedChannels.add(channel);
                }
            }

            Set<Integer> friendsIds = userDto.getFriendsIds();
            Set<User> selectedFriends = new HashSet<>();

            if (friendsIds != null && !friendsIds.isEmpty()) {
                // 1. Прочитаме всички потребители, които ще бъдат добавени в списъка с приятели
                for (Integer userId : friendsIds) {
                    User friend = usersRepository.findById(userId).orElseThrow(() -> new ExpressionException("User with ID " + userId + " not found"));
                    selectedFriends.add(friend);
                }

                // 2. Добавяме текущия потребител (потребителя, който избира новите приятели) към списъка с приятели на избраните потребители
                for (User friend : selectedFriends) {
                    // Добавяме текущия потребител към приятелите на избраните потребители
                    friend.getFriends().add(user);

                    usersRepository.save(friend);
                }

                // 3. Сега добавяме избраните потребители като приятели на текущия потребител
                user.getFriends().addAll(selectedFriends);

                // 4. Записваме промените на текущия потребител
                usersRepository.save(user);
            }


            user.setChannels(selectedChannels);
            user.setFriends(selectedFriends);

            usersRepository.save(user);
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
        }

        return "redirect:/";
    }
}
