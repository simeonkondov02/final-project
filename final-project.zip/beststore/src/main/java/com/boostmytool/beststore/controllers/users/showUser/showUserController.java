package com.boostmytool.beststore.controllers.users.showUser;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boostmytool.beststore.models.channel.Channel;
import com.boostmytool.beststore.models.user.User;
import com.boostmytool.beststore.models.user.UserDto;
import com.boostmytool.beststore.services.UsersRepository;

@Controller
@RequestMapping("/users")
public class showUserController {
    @Autowired private UsersRepository usersRepository;

    @GetMapping("/user")
    public String showUserPage(Model model, @RequestParam int id) {
        try {
            User user = usersRepository.findById(id).get();

            Set<User> friends = user.getFriends();
            Set<Channel> channels = user.getChannels();

            UserDto userDto = new UserDto();
            userDto.setName(user.getName());

            model.addAttribute("user", user);
            model.addAttribute("userDto", userDto);
            model.addAttribute("friends", friends);
            model.addAttribute("channels", channels);
        } catch(Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "redirect:/users";
        }

        return "users/ShowUser";
    }
}
